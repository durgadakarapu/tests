import React from 'react';
import ForecastDataView from './app/forecast/components/ForecastDataView';
import './App.css';

function App() {
  return (
    <ForecastDataView/>
  );
}

export default App;
